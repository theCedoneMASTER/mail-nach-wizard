"""
Hilfsfunktionen für Datum, Länder, Formatierung
"""
from datetime import datetime
import pycountry
from babel import Locale


def get_country_name(country_code: str, lang: str = 'de') -> str:
    """
    Übersetzt ISO-2 Ländercode in Ländername
    
    Args:
        country_code: ISO-2 Code (z.B. 'DE', 'CH')
        lang: Sprache ('de' oder 'en')
    
    Returns:
        Ländername in der gewünschten Sprache
    """
    try:
        country = pycountry.countries.get(alpha_2=country_code.upper())
        if not country:
            return f"Unbekannter Ländercode: {country_code}"
        
        locale = Locale(lang)
        localized_name = locale.territories.get(country.alpha_2)
        
        return localized_name if localized_name else country.name
    except Exception as e:
        return str(e)


def format_date(iso_date: str, lang: str = 'de', with_suffix: bool = False) -> str:
    """
    Formatiert ISO-Datum in lesbare Form
    
    Args:
        iso_date: Datum im Format YYYY-MM-DD
        lang: Sprache ('de' oder 'en')
        with_suffix: Suffix für EN (1st, 2nd, 3rd) hinzufügen
    
    Returns:
        Formatiertes Datum
    """
    date_obj = datetime.strptime(iso_date, "%Y-%m-%d")
    
    if lang == 'de':
        return date_obj.strftime("%d.%m.%Y")
    
    elif lang == 'en':
        day = date_obj.day
        suffix = ''
        
        if with_suffix:
            if 11 <= day <= 13:
                suffix = "th"
            else:
                suffix = {1: "st", 2: "nd", 3: "rd"}.get(day % 10, "th")
        
        return f"{day}{suffix} {date_obj.strftime('%B %Y')}"
    
    return iso_date


def format_currency(amount: float, currency: str = '€') -> str:
    """
    Formatiert Geldbetrag
    
    Args:
        amount: Betrag
        currency: Währungssymbol
    
    Returns:
        Formatierter Betrag (z.B. "1.234,56 €")
    """
    return f"{amount:,.2f} {currency}".replace(',', 'X').replace('.', ',').replace('X', '.')


def build_contact_string(*parts) -> str:
    """
    Baut Kontakt-String aus Teilen (entfernt leere Teile)
    
    Args:
        *parts: Variable Anzahl von String-Teilen
    
    Returns:
        Zusammengesetzter String mit " | " als Separator
    """
    filtered = [part for part in parts if part and len(part.strip()) > 0]
    return ' | '.join(filtered)


def clean_multiline_string(text: str) -> str:
    """
    Entfernt überflüssige Leerzeilen am Anfang und Ende
    
    Args:
        text: Mehrzeiliger String
    
    Returns:
        Bereinigter String
    """
    return text.strip()
