# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

HotelFriend Invoice System — a Flask web app for generating professional invoices, offers, and performance slips as PDFs. Supports two companies (GmbH & AG) and two languages (DE & EN).

## Running the App

```bash
pip install -r requirements.txt
python app.py
# Runs on http://127.0.0.1:5030
```

No build step, no test suite, no linter configured.

## Architecture

**Request flow:** HTML form → Flask route (app.py) → `process_document_creation()` → `create_document_pdf()` (pdf_generator.py) → PDF saved to `static/`

**Key design principles:**
- **Single processing path:** All three document types flow through `process_document_creation()` in app.py. Invoice/offer share the table rendering (`add_items_table`/`add_totals_table`). Performance slip has its own branch that returns early with dedicated section rendering.
- **Config-driven:** Companies, reverse-charge countries, colors, and paths are centralized in config.py
- **Document type registry:** `DocumentType` dataclasses in document_types.py define labels, templates, and filenames per type — add new document types here
- **Stateless persistence:** Recipients stored in `recipients.json`, no database

## Module Responsibilities

| Module | Role |
|---|---|
| **config.py** | Central configuration: companies, colors, paths, reverse-charge country list |
| **document_types.py** | `DocumentType` dataclass definitions (INVOICE, OFFER, PERFORMANCE_SLIP) |
| **app.py** | Flask routes, form data processing, data block builders |
| **pdf_generator.py** | `DocumentPDF` class (extends FPDF), rendering, text wrapping, `create_document_pdf()` entry point |
| **utils.py** | Date/currency formatting, country name lookup, string helpers |
| **pdf_generator_nofooter.py** | Alternative PDF generator without footer (legacy) |

## Language & Localization

Every user-facing string has DE/EN variants. Number formatting differs by language (DE: `1.000,50` / EN: `1,000.50`). Date formats use Babel (`01.01.2024` vs `1st January 2024`). Document type fields, titles, and note templates are all language-keyed in document_types.py.

## Key Business Logic

- **Reverse-charge:** Triggered automatically for 33 countries listed in `REVERSE_CHARGE_COUNTRIES` (config.py). Hides VAT rows and appends a reverse-charge notice.
- **Performance slip (Leistungsschein):** Uses the same header/footer/receiver/details layout as invoice/offer, but has its own rendering path in `create_document_pdf()` with sections A-F (Projekt, Erbrachte Leistungen, In Bearbeitung, Offen, Abrechnungsgrundlage, Bestätigung). Items are grouped by status and rendered in `add_performance_items_table()` with 3 columns (Pos/Beschreibung/Kosten). Each item has a bold title line and a description paragraph below. Items carry custom position numbers (`art_pos`). Extra parameters: `project_info`, `closing_name`, `closing_title`, `deposit_percent`.
- **Company switching:** GmbH/AG have different logos, footer data, and sender lines. Footer content is resolved in `_get_footer_data()` in pdf_generator.py.

## Extending the System

**New document type:** Add a `DocumentType` instance to document_types.py → add a Flask route in app.py → create an HTML template in `templates/` → call `process_document_creation()`.

**New company:** Add to `COMPANIES` in config.py → add logo to `sources/` → add footer data in `_get_footer_data()` in pdf_generator.py.

**New reverse-charge country:** Add ISO-2 code to `REVERSE_CHARGE_COUNTRIES` in config.py.

## Routes

- `/rechnung` — Invoice form
- `/angebot` — Offer form
- `/leistungsschein` — Performance slip form
- `/recipients` — Recipient management
- `POST /create-pdf`, `/create-offer`, `/create-performance-slip` — PDF generation endpoints

## Assets

- Fonts: `sources/Roboto-*.ttf`
- Logos: `sources/logo-gmbh.png`, `sources/logo-ag.png`
- Generated PDFs: `static/`
