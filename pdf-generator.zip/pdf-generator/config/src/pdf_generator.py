"""
Universeller PDF-Generator für alle Dokumenttypen
Basiert auf FPDF, wiederverwendbar für Rechnung, Angebot, etc.
"""
from fpdf import FPDF
from typing import List, Tuple, Optional
import os
from config import COMPANIES, COLORS, FONTS_DIR
from document_types import DocumentType

def format_number(number_in: float, lang: str = 'DE') -> str:
    """
    Formatiert Zahlen sprachabhängig und entfernt unnötige Nachkommastellen
    
    Args:
        number_in: Zu formatierende Zahl
        lang: Sprache ('DE' oder 'EN')
    
    Returns:
        Formatierte Zahl als String
    
    Beispiele:
        DE: 2.0 → "2"  |  2.5 → "2,5"  |  1000 → "1.000"
        EN: 2.0 → "2"  |  2.5 → "2.5"  |  1000 → "1,000"
    """
    # Wenn ganzzahlig, keine Nachkommastellen
    if isinstance(number_in, (int, float)) and number_in == int(number_in):
        string_out = f"{int(number_in):,}"
    else:
        string_out = f"{number_in:,}"
    
    # Deutsche Formatierung: Punkt/Komma tauschen
    if lang == "DE":
        string_out = string_out.replace('.', 'X').replace(',', '.').replace('X', ',')
    
    return string_out


def format_currency(number_in: float, lang: str = 'DE', currency: str = ' €') -> str:
    """
    Formatiert Währungsbeträge sprachabhängig mit 2 Nachkommastellen
    
    Args:
        number_in: Zu formatierende Zahl
        lang: Sprache ('DE' oder 'EN')
        currency: Währungssymbol (Standard: ' €')
    
    Returns:
        Formatierte Währung als String
    
    Beispiele:
        DE: 100.5 → "100,50 €"  |  1000 → "1.000,00 €"
        EN: 100.5 → "100.50 €"  |  1000 → "1,000.00 €"
    """
    string_out = f"{number_in:,.2f}"
    
    # Deutsche Formatierung: Punkt/Komma tauschen
    if lang == "DE":
        string_out = string_out.replace('.', 'X').replace(',', '.').replace('X', ',')
    
    return string_out + currency


class DocumentPDF(FPDF):
    """
    Basis-PDF-Klasse für alle Dokumente
    Erweitert FPDF um HotelFriend-spezifisches Layout
    """
    
    def __init__(self, company: str = 'gmbh', *args, **kwargs):
        """
        Initialisiert das PDF-Dokument
        
        Args:
            company: 'gmbh' oder 'ag'
        """
        super().__init__(*args, **kwargs)
        
        if company not in COMPANIES:
            raise ValueError(f"Unbekannte Firma: {company}. Verwende 'gmbh' oder 'ag'")
        
        self.company = company
        self.company_data = COMPANIES[company]
        self.sprache = 'DE'  # Default, wird später gesetzt
        
        # Farben definieren (MUSS vor add_page() sein!)
        self.color_black = COLORS['black']
        self.color_dark_blue = COLORS['dark_blue']
        self.color_light_blue = COLORS['light_blue']
        self.color_white = COLORS['white']
        
        # Fonts registrieren
        self._register_fonts()
        
        # PDF-Setup
        self.set_auto_page_break(auto=True, margin=26)
        self.set_margins(left=25, top=25, right=20)
        self.add_page()
    
    def _register_fonts(self):
        """Registriert die Roboto-Schriftarten"""
        try:
            self.add_font('Roboto', '', f'{FONTS_DIR}/Roboto-Light.ttf', uni=True)
            self.add_font('Roboto', 'I', f'{FONTS_DIR}/Roboto-LightItalic.ttf', uni=True)
            self.add_font('Roboto', 'B', f'{FONTS_DIR}/Roboto-Medium.ttf', uni=True)
        except Exception as e:
            print(f"⚠️  Warnung: Fonts konnten nicht geladen werden: {e}")
            print(f"    Stelle sicher, dass die .ttf-Dateien in '{FONTS_DIR}/' liegen")
    
    def set_sprache(self, sprache: str):
        """Setzt die Sprache für den Footer"""
        self.sprache = sprache
    
    def header(self):
        """Header für jede Seite (Logo + Linie)"""
        # Logo oben rechts
        logo_path = self.company_data['logo']
        if os.path.exists(logo_path):
            self.image(logo_path, x=140, y=15, w=51)
        
        # Linie unter dem Logo
        self.set_y(29)
        self.set_draw_color(*self.color_light_blue)
        self.set_line_width(0.5)
        self.line(25, self.get_y(), 190, self.get_y())
        self.ln(10)
    
    def footer(self):
        """Footer mit Firmendaten-Tabelle (wie im alten Code)"""
        # Positionierung der Linie im Footer
        self.set_y(-26)
        self.set_draw_color(*self.color_light_blue)
        self.set_line_width(0.5)
        self.line(25, self.get_y(), 190, self.get_y())
        
        # Fußzeilentabelle
        self.set_y(-24)
        self.set_font('Roboto', size=6)
        self.set_text_color(*self.color_black)
        
        footer_data = self._get_footer_data()
        
        # Spaltenbreiten
        page_width = 210
        margin_left = 25
        margin_right = 20
        available_width = page_width - margin_left - margin_right
        col_width = available_width / 4
        
        # Tabelle zeichnen
        for row in footer_data:
            for col in row:
                self.cell(col_width, 2, col, border=0, align='L')
            self.ln(2.5)
    
    def _get_footer_data(self):
        """Gibt Footer-Daten basierend auf Firma und Sprache zurück"""
        if self.company == 'gmbh':
            if self.sprache == 'DE':
                return [
                    ["HotelFriend Service GmbH", "Web: www.hotelfriend.de", "Amtsgericht Charlottenburg", "Bankverbindung"],
                    ["Friedrichstraße 171", "Mail: office@hotelfriend.de", "HRB 192302 B", "Deutsche Bank"],
                    ["D-10117 Berlin", "", "Sitz: Berlin", "Technology Sector Coverage"],
                    ["", "Fon: +49 30 46999 5418", "Steuernummer: 30/354/50352", "IBAN DE60 1007 0100 0161 3686 00"],
                    ["Geschäftsführer: Denis Severyuk", "Fax: +49 30 46999 5419", "Ust-IdNr: DE315262361", "BIC: DEUTDEBB101"],
                    ["", "", "", ""]
                ]
            else:  # EN
                return [
                    ["HotelFriend Service GmbH", "Web: www.hotelfriend.com", "Charlottenburg District Court", "Bank Account"],
                    ["Friedrichstraße 171", "Email: office@hotelfriend.de", "HRB 192302 B", "Deutsche Bank"],
                    ["D-10117 Berlin", "", "Registered Office: Berlin, Germany", "Technology Sector Coverage"],
                    ["", "Phone: +49 30 46999 5418", "Tax Number: 30/354/50352", "IBAN DE60 1007 0100 0161 3686 00"],
                    ["Managing Director: Denis Severyuk", "Fax: +49 30 46999 5419", "VAT-ID: DE315262361", "BIC: DEUTDEBB101"],
                    ["", "", "", ""]
                ]
        else:  # ag
            if self.sprache == 'DE':
                return [
                    ["HotelFriend AG", "office@hotelfriend.de", "Amtsgericht Charlottenburg", "Bankverbindung"],
                    ["Friedrichstraße 171", "Fon: +49 30 46999 5418", "HRB 191543 B", "Deutsche Bank"],
                    ["D-10117 Berlin", "Fax: +49 30 46999 5419", "Sitz: Berlin", "Technology Sector Coverage"],
                    ["", "", "", "IBAN DE61 1007 0100 0161 2225 00"],
                    ["Vorstand", "Vorsitzender des Aufsichtsrats", "Steuernummer: 30/354/50344", "BIC: DEUTDEBB101"],
                    ["Denis Severyuk", "Besarioni Kamarauli", "Ust-IdNr: DE315013764", ""]
                ]
            else:  # EN
                return [
                    ["HotelFriend AG", "Email: office@hotelfriend.de", "Charlottenburg District Court", "Bank Account"],
                    ["Friedrichstraße 171", "Phone: +49 30 46999 5418", "HRB 191543 B", "Deutsche Bank"],
                    ["D-10117 Berlin", "Fax: +49 30 46999 5419", "Registered Office: Berlin, Germany", "Technology Sector Coverage"],
                    ["", "", "", "IBAN DE61 1007 0100 0161 2225 00"],
                    ["Chair of the Executive Board", "Chair of the Supervisory Board", "Tax Number: 30/354/50344", "BIC: DEUTDEBB101"],
                    ["Denis Severyuk", "Besarioni Kamarauli", "VAT-ID: DE315013764", ""]
                ]
    
    def add_receiver_block(self, receiver_content: str, sender_line: str):
        """
        Empfänger-Block (DIN-Fenster)
        
        Args:
            receiver_content: Mehrzeiliger Empfänger-Text
            sender_line: Sender-Zeile (klein, fett)
        """
        # Positionierung für DIN-Fenster
        self.set_xy(25, 45)
        
        # Sender-Zeile (klein, fett)
        self.set_font('Roboto', 'B', 8)
        self.set_text_color(*self.color_black)
        self.multi_cell(0, 5, sender_line)
        self.ln(2)
        
        # Empfänger (normal)
        self.set_font('Roboto', size=9)
        self.set_text_color(*self.color_black)
        self.multi_cell(0, 5, receiver_content)
    
    def add_details_block(self, content: str):
        """
        Details-Block (rechts oben)
        
        Args:
            content: Mehrzeiliger Details-Text (rechtsbündig)
        """
        x = 120
        y = 52
        width = 70
        
        self.set_xy(x, y)
        self.set_font('Roboto', size=9)
        self.set_text_color(*self.color_black)
        self.multi_cell(width, 5, content, align='R')
    
    def add_document_title(self, title: str):
        """
        Dokumenttitel (z.B. "Rechnung Nr. 2024-001")
        
        Args:
            title: Titel-Text
        """
        self.set_xy(25, 110)
        self.set_font('Roboto', size=10, style='B')
        self.set_text_color(*self.color_black)
        self.cell(0, 10, title, ln=True)
    
    def add_period(self, period: str):
        """
        Leistungszeitraum (z.B. "01.01.2024 - 31.01.2024")
        
        Args:
            period: Zeitraum-Text
        """
        self.set_xy(25, 115)
        self.set_font('Roboto', size=9, style='I')
        self.set_text_color(*self.color_black)
        self.cell(0, 10, period, ln=True)

    def add_pretext(self, pretext: str):
        """
        Optionaler Einleitungstext vor der Positionstabelle.
        Wird mit mehrzeiligem Umbruch dargestellt.
        """
        self.ln(3)
        self.set_font('Roboto', '', 9)
        self.set_text_color(*self.color_black)
        page_width = 210
        margin_left = 25
        margin_right = 20
        self.multi_cell(page_width - margin_left - margin_right, 5, pretext)
    
    def add_items_table(self, items: List[List], headers: List[str]):
        """
        Artikel-Tabelle mit blauem Header und automatischem Zeilenumbruch
        
        Args:
            items: Liste von Listen [Pos, Beschreibung, Menge, Einzelpreis, Gesamt]
            headers: Header-Zeile (Liste von Strings)
        """
        # Spaltenbreiten
        page_width = 210
        margin_left = 25
        margin_right = 20
        available_width = page_width - margin_left - margin_right
        
        col_widths = [
            available_width * 0.1,   # Position
            available_width * 0.5,   # Beschreibung
            available_width * 0.1,   # Menge
            available_width * 0.15,  # Einzelpreis
            available_width * 0.15,  # Gesamt
        ]
        
        # ✅ Zellenhöhe und Abstände trennen!
        cell_height = 5                 # Feste Zellenhöhe (für Text)
        spacing_between_items = 6       # Abstand zwischen verschiedenen Artikeln (Pos 1 → Pos 2)
        spacing_within_item = 4         # ✅ Abstand innerhalb umgebrochener Beschreibung (auch Zeile 1 → 2!)
        
        # Tabelle zeichnen
        self.set_font('Roboto', size=9)
        self.set_text_color(*self.color_black)
        
        # Manuelle Y-Position für komplette Kontrolle
        current_y = self.get_y() + 3
        x_start = margin_left
        
        # Header-Zeile (blauer Hintergrund)
        self.set_fill_color(*self.color_light_blue)
        self.set_font('Roboto', style='B', size=9)
        self.set_text_color(*self.color_white)
        
        self.set_xy(x_start, current_y)
        for i, header in enumerate(headers):
            align = 'R' if i in [3, 4] else 'L' if i == 0 else 'L'
            text = f"  {header}" if align == 'L' else f"{header}  " if align == 'R' else header
            self.cell(col_widths[i], cell_height, text, border=0, align=align, fill=True)
        
        # Nach Header
        current_y += spacing_between_items
        
        # Datenzeilen mit automatischem Zeilenumbruch
        self.set_font('Roboto', style='', size=9)
        self.set_text_color(*self.color_black)
        
        for row_index, row in enumerate(items):
            # Beschreibung in Zeilen aufteilen
            description = str(row[1])
            description_lines = self._split_text_into_lines(description, col_widths[1])
            num_lines = len(description_lines)
            
            # ✅ ERSTE ZEILE des Artikels
            self.set_xy(x_start, current_y)
            
            # Position
            self.cell(col_widths[0], cell_height, str(row[0]), border=0, align='C')
            
            # Beschreibung (erste Zeile)
            text = f"  {description_lines[0]}"
            self.cell(col_widths[1], cell_height, text, border=0, align='L')
            
            # Menge (Strich bei 0)
            qty_str = "--" if str(row[2]).strip() in ["0", "0.0", "0,0", ""] else str(row[2])
            text = f"{qty_str}  "
            self.cell(col_widths[2], cell_height, text, border=0, align='C')

            # Einzelpreis (Strich bei 0)
            price_str = "--" if str(row[3]).strip() in ["0", "0.0", "0,0", "0,00 €", "0.00 €", ""] else str(row[3])
            text = f"{price_str}  "
            self.cell(col_widths[3], cell_height, text, border=0, align='R')

            # Gesamt (Strich bei 0)
            total_str = "--" if str(row[4]).strip() in ["0", "0.0", "0,0", "0,00 €", "0.00 €", ""] else str(row[4])
            text = f"{total_str}  "
            self.cell(col_widths[4], cell_height, text, border=0, align='R')
            
            # ✅ Nach erster Zeile: 
            # - Wenn mehrzeilig: kompakter Abstand (4mm) zur zweiten Zeile des GLEICHEN Artikels
            # - Wenn einzeilig: normaler Abstand (6mm) zum nächsten Artikel
            if num_lines > 1:
                current_y += spacing_within_item  # ✅ 4mm zur Zeile 2 des gleichen Artikels!
            else:
                current_y += spacing_between_items  # 6mm zum nächsten Artikel
            
            # ✅ FOLGEZEILEN (umgebrochener Text innerhalb des Artikels)
            if num_lines > 1:
                for line_idx in range(1, num_lines):
                    self.set_xy(x_start, current_y)
                    
                    # Leere Spalten
                    self.cell(col_widths[0], cell_height, '', border=0)
                    
                    # Beschreibung (Folgezeile)
                    text = f"  {description_lines[line_idx]}"
                    self.cell(col_widths[1], cell_height, text, border=0, align='L')
                    
                    self.cell(col_widths[2], cell_height, '', border=0)
                    self.cell(col_widths[3], cell_height, '', border=0)
                    self.cell(col_widths[4], cell_height, '', border=0)
                    
                    # ✅ Nach Folgezeile:
                    # - Wenn nicht letzte Zeile: kompakter Abstand (4mm)
                    # - Wenn letzte Zeile: normaler Abstand (6mm) zum nächsten Artikel
                    if line_idx < num_lines - 1:
                        current_y += spacing_within_item  # 4mm zur nächsten Zeile des gleichen Artikels
                    else:
                        current_y += spacing_between_items  # 6mm zum nächsten Artikel
        
        # Finale Y-Position setzen
        self.set_y(current_y)
        
        return col_widths


    def _split_text_into_lines(self, text: str, width: float) -> List[str]:
        """
        Teilt Text in Zeilen auf, die in die gegebene Breite passen
        
        Args:
            text: Der zu teilende Text
            width: Verfügbare Breite
        
        Returns:
            Liste von Textzeilen
        """
        # Durchschnittliche Zeichenbreite bei Roboto 9pt: ~2.5mm
        char_width = 1.5
        
        # Abzug für "  " (2 Leerzeichen Einrückung)
        effective_width = width - (2*char_width)
        chars_per_line = int(effective_width / char_width)
        
        if chars_per_line <= 0:
            return [text]
        
        # Text in Wörter zerlegen
        words = text.split()
        lines = []
        current_line = []
        current_length = 0
        
        for word in words:
            word_length = len(word)
            
            # Prüfe ob Wort in aktuelle Zeile passt (+ Leerzeichen)
            test_length = current_length + word_length + (1 if current_line else 0)
            
            if test_length <= chars_per_line:
                current_line.append(word)
                current_length = test_length
            else:
                # Aktuelle Zeile abschließen
                if current_line:
                    lines.append(' '.join(current_line))
                current_line = [word]
                current_length = word_length
        
        # Letzte Zeile hinzufügen
        if current_line:
            lines.append(' '.join(current_line))
        
        return lines if lines else [text]


    
    def add_totals_table(self, totals: List[Tuple[str, str]], col_widths: List[float], y_start: float):
        """
        Summen-Tabelle (Zwischensumme, MwSt, Gesamt)
        
        Args:
            totals: Liste von Tupeln [(Label, Wert), ...]
            col_widths: Spaltenbreiten aus add_items_table
            y_start: Y-Position wo die Tabelle beginnen soll
        """
        self.set_y(y_start)
        self.set_font('Roboto', size=9)
        self.set_text_color(*self.color_black)
        
        # Start-Position (ab Menge-Spalte)
        x_start = 25 + sum(col_widths[:2])
        total_width = sum(col_widths[2:])
        col_width_left = total_width * 0.6
        col_width_right = total_width * 0.4
        
        for index, (label, value) in enumerate(totals):
            self.set_x(x_start)
            
            # Dünne Linie über erster Zeile
            if index == 0:
                self.set_draw_color(*self.color_black)
                self.set_line_width(0.2)
                self.line(x_start, self.get_y(), x_start + total_width, self.get_y())
            
            # Letzte Zeile: Blauer Hintergrund
            if index == len(totals) - 1:
                self.set_fill_color(*self.color_light_blue)
                self.set_font('Roboto', style='B', size=9)
                self.set_text_color(*self.color_white)
                value = f"{value}  "
                
                self.cell(col_width_left, 6, f" {label}", border=0, align='L', fill=True)
                self.cell(col_width_right, 6, value, border=0, align='R', fill=True)
            else:
                self.set_font('Roboto', style='', size=9)
                self.set_text_color(*self.color_black)
                value = f"{value}  "
                self.cell(col_width_left, 6, f" {label}", border=0, align='L')
                self.cell(col_width_right, 6, value, border=0, align='R')
            
            self.ln(6)
    
    def add_note(self, note: str):
        """
        Abschlusstext / Notiz am Ende

        Args:
            note: Mehrzeiliger Notiz-Text
        """
        self.ln(10)
        self.set_font('Roboto', size=9)
        self.set_text_color(*self.color_black)

        # Breite begrenzen (wie im alten Code)
        page_width = 210
        margin_left = 25
        margin_right = 20
        available_width = page_width - margin_left - margin_right
        lorem_width = available_width * (7 / 12)

        self.multi_cell(lorem_width, 5, note)

    def add_section_heading(self, heading: str, intro_text: str = None):
        """
        Sektionsüberschrift für Leistungsschein (z.B. 'B  ERBRACHTE LEISTUNGEN')
        """
        if self.get_y() > 250:
            self.add_page()
        self.ln(8)
        self.set_font('Roboto', 'B', 10)
        self.set_text_color(*self.color_black)
        self.cell(0, 6, heading, ln=True)
        if intro_text:
            self.ln(1)
            self.set_font('Roboto', '', 9)
            self.multi_cell(0, 5, intro_text)

    def add_performance_items_table(self, items, lang: str = 'DE'):
        """
        Leistungsschein-Tabelle: Pos | Beschreibung | Kosten

        Args:
            items: Liste von [pos, title, description, cost, status]
            lang: 'DE' oder 'EN'
        """
        margin_left = 25
        available_width = 165

        col_pos = 13
        col_desc = available_width - 13 - 33  # 119mm
        col_cost = 33

        headers = ['Pos', 'Beschreibung', 'Kosten'] if lang == 'DE' else ['Pos', 'Description', 'Cost']

        # Blue header bar
        self.ln(2)
        self.set_fill_color(*self.color_light_blue)
        self.set_font('Roboto', 'B', 9)
        self.set_text_color(*self.color_white)

        self.cell(col_pos, 5, f'  {headers[0]}', fill=True)
        self.cell(col_desc, 5, f'  {headers[1]}', fill=True)
        self.cell(col_cost, 5, f'{headers[2]}  ', align='R', fill=True)
        self.ln(6)

        self.set_text_color(*self.color_black)

        for item in items:
            pos_str = str(item[0])
            title = str(item[1])
            description = str(item[2]) if len(item) > 2 else ''
            cost = float(item[3]) if len(item) > 3 else 0.0
            cost_str = format_currency(cost, lang)

            # Page break check
            if self.get_y() > 255:
                self.add_page()

            # Title line: Pos + bold title + cost
            self.set_font('Roboto', 'B', 9)
            self.set_x(margin_left)
            self.cell(col_pos, 5, pos_str, align='C')
            self.cell(col_desc, 5, f'  {title}', align='L')
            self.cell(col_cost, 5, f'{cost_str}  ', align='R')
            self.ln(6)

            # Description (aligned with title text, spans to right edge with padding)
            if description.strip():
                self.set_font('Roboto', '', 9)
                desc_x = margin_left + col_pos + 1.5
                old_lm = self.l_margin
                self.set_left_margin(desc_x)
                self.set_x(desc_x)
                self.multi_cell(col_desc + col_cost - 1.5 - 1.5, 4.5, description)
                self.set_left_margin(old_lm)

            self.ln(2)


def create_document_pdf(
    filename: str,
    document_type: DocumentType,
    company: str,
    language: str,
    receiver: str,
    document_number: str,
    document_title_suffix: str,
    details: str,
    period: str,
    pretext: str,
    items: List[List],
    note: str,
    custom_note: str = '',
    reverse_charge: bool = False,
    project_info: str = '',
    closing_name: str = '',
    closing_title: str = '',
    deposit_percent: str = '',
) -> str:
    """
    Hauptfunktion: Erstellt ein PDF-Dokument
    
    Args:
        filename: Ziel-Dateipfad
        document_type: DocumentType-Objekt (INVOICE, OFFER, etc.)
        company: 'gmbh' oder 'ag'
        language: 'DE' oder 'EN'
        receiver: Empfänger-Textblock
        document_number: Dokumentnummer
        document_title_suffix: Optionaler Titel-Zusatz
        details: Details-Textblock (rechts)
        period: Leistungszeitraum-Text
        pretext: Text vor der Positionstabelle
        items: Artikel-Liste
        note: Abschlusstext
        reverse_charge: Ob Reverse-Charge gilt
    
    Returns:
        Dateipfad des erstellten PDFs
    """
    lang = language.lower()
    lang_upper = language.upper()
    
    # PDF initialisieren
    pdf = DocumentPDF(company=company)
    pdf.set_sprache(language.upper())
    
    # Sender-Zeile
    sender_line = pdf.company_data[f'sender_line_{lang}']
    
    # Header + Empfänger
    pdf.add_receiver_block(receiver, sender_line)
    
    # Details rechts
    pdf.add_details_block(details)
    
    # Dokumenttitel
    title_template = document_type.title_de if lang == 'de' else document_type.title_en
    title = title_template.format(number=document_number)
    if document_title_suffix:
        title += f" - {document_title_suffix}"
    pdf.add_document_title(title)
    
    # Special layout for Rough Indication: sections A-F with fixed text blocks
    if document_type.type_id == 'rough_indication':
        # Intro text (salutation + standard introductory paragraph)
        if pretext:
            pdf.ln(3)
            pdf.set_font('Roboto', '', 9)
            page_width = 210
            margin_left = 25
            margin_right = 20
            pdf.multi_cell(page_width - margin_left - margin_right, 5, pretext)

        # A RESSOURCEN
        if pdf.get_y() > 250:
            pdf.add_page()
        pdf.ln(6)
        pdf.set_font('Roboto', 'B', 10)
        pdf.set_text_color(*pdf.color_black)
        if lang == 'de':
            pdf.cell(0, 6, 'A  RESSOURCEN', ln=True)
            pdf.ln(2)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'Wir stellen für Sie ein Scrum Team, bestehend aus Projektleitung, technischer Leitung, '
                'Entwicklung, UI/UX Design, Qualitätsmanagement und DevOps zusammen. Der Team-Stundensatz '
                'dieser Indikation stellt eine Mischkalkulation für ein durchschnittliches Entwicklerteam dar. '
                'Ein Teamtag (TT) umfasst acht Teamstunden.')
        else:
            pdf.cell(0, 6, 'A  RESOURCES', ln=True)
            pdf.ln(2)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'We will assemble a Scrum team for you, consisting of project management, technical management, '
                'development, UI/UX design, quality management and DevOps. The team hourly rate of this indication '
                'represents a blended calculation for an average development team. A team day (TD) comprises eight '
                'team hours.')

        # B LEISTUNGSPOSITIONEN
        if lang == 'de':
            pdf.add_section_heading('B  LEISTUNGSPOSITIONEN')
        else:
            pdf.add_section_heading('B  SERVICE ITEMS')
        if items:
            pdf.add_performance_items_table(items, lang_upper)
        else:
            pdf.ln(2)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, '-')

        # C ERFÜLLUNG UND LIEFERUNG
        if pdf.get_y() > 250:
            pdf.add_page()
        pdf.ln(8)
        pdf.set_font('Roboto', 'B', 10)
        pdf.set_text_color(*pdf.color_black)
        if lang == 'de':
            pdf.cell(0, 6, 'C  ERFÜLLUNG UND LIEFERUNG', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'Die geschätzte Entwicklungszeit deckt keine zusätzlichen Anforderungen ab, die sich aus '
                'Wünschen für Änderungen und Anpassungen im Laufe der Fertigstellung / Übergabe ergeben. '
                'Reisekosten für persönliche Treffen und Schulungen vor Ort sind ebenfalls nicht berücksichtigt.')
        else:
            pdf.cell(0, 6, 'C  FULFILLMENT AND DELIVERY', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'The estimated development time does not cover additional requirements arising from requests '
                'for changes and adjustments during the completion/handover. Travel costs for personal meetings '
                'and on-site training are also not included.')

        # D ZAHLUNGSBEDINGUNGEN
        if pdf.get_y() > 250:
            pdf.add_page()
        pdf.ln(8)
        pdf.set_font('Roboto', 'B', 10)
        pdf.set_text_color(*pdf.color_black)
        pct = deposit_percent if deposit_percent else '50'
        if lang == 'de':
            pdf.cell(0, 6, 'D  ZAHLUNGSBEDINGUNGEN', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                f'{pct}% der geschätzten Entwicklungskosten sind bei Auftragserteilung fällig. '
                'Die Verrechnung mit den real entstandenen Kosten und die Fälligkeit des Restbetrags '
                'erfolgt bei Abnahme.')
        else:
            pdf.cell(0, 6, 'D  PAYMENT TERMS', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                f'{pct}% of the estimated development costs are due upon placement of the order. '
                'The offset against the actual costs incurred and the remaining amount are due upon acceptance.')

        # E ALLGEMEINE GESCHÄFTSBEDINGUNGEN
        if pdf.get_y() > 250:
            pdf.add_page()
        pdf.ln(8)
        pdf.set_font('Roboto', 'B', 10)
        pdf.set_text_color(*pdf.color_black)
        if lang == 'de':
            pdf.cell(0, 6, 'E  ALLGEMEINE GESCHÄFTSBEDINGUNGEN', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, 'Es gelten die Allgemeinen Geschäftsbedingungen von HotelFriend.')
        else:
            pdf.cell(0, 6, 'E  GENERAL TERMS AND CONDITIONS', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, 'The General Terms and Conditions of HotelFriend apply.')

        # F SONSTIGES
        if pdf.get_y() > 240:
            pdf.add_page()
        pdf.ln(8)
        pdf.set_font('Roboto', 'B', 10)
        pdf.set_text_color(*pdf.color_black)
        if lang == 'de':
            pdf.cell(0, 6, 'F  SONSTIGES', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'Dies ist eine Grobindikation auf Basis der aktuell vorhandenen Informationen. In weiteren '
                'Projektmeetings werden die Anforderungen weiter detailliert und eine genauere Aufwandsabschätzung '
                'wird vorgenommen.\n\n'
                'Wir freuen uns darauf, mit Ihnen gemeinsam an diesem Projekt zu arbeiten und innovative Lösungen '
                'zu schaffen. Zögern Sie nicht, uns bei Fragen oder für weitere Informationen zu kontaktieren. '
                'Wir freuen uns über die Möglichkeit, mit Ihnen zusammenzuarbeiten und eine erfolgreiche '
                'Partnerschaft zu gestalten.')
        else:
            pdf.cell(0, 6, 'F  MISCELLANEOUS', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'This is a rough indication based on the currently available information. In further project '
                'meetings, the requirements will be further detailed and a more precise effort estimate will '
                'be made.\n\n'
                'We look forward to working together with you on this project and creating innovative solutions. '
                'Do not hesitate to contact us with questions or for further information. We look forward to the '
                'opportunity of working with you and building a successful partnership.')

        # Closing greeting + sender info
        pdf.ln(10)
        pdf.set_font('Roboto', '', 9)
        pdf.multi_cell(0, 5, note)

        if closing_name:
            pdf.ln(8)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, closing_name)
        if closing_title:
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, closing_title)
            pdf.multi_cell(0, 5, pdf.company_data['name'])

        pdf.output(filename)
        return filename

    # Special layout for Performance Slip: sections A-F with grouped items
    if document_type.type_id == 'performance_slip':
        # Intro text (salutation + introductory paragraph)
        if pretext:
            pdf.ln(3)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(120, 5, pretext)

        # A PROJEKT section
        if project_info:
            pdf.ln(6)
            pdf.set_font('Roboto', 'B', 10)
            pdf.set_text_color(*pdf.color_black)
            heading_a = 'A  PROJEKT' if lang == 'de' else 'A  PROJECT'
            pdf.cell(0, 6, heading_a, ln=True)
            pdf.ln(2)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(120, 5, project_info)

        # Group items by status
        done_items = [it for it in items if it[4] == 'done']
        inprogress_items = [it for it in items if it[4] == 'in_progress']
        open_items = [it for it in items if it[4] == 'open']

        # Sections B, C, D
        if lang == 'de':
            sections = [
                ('B  ERBRACHTE LEISTUNGEN',
                 'Die folgenden Leistungen wurden gemäß Vertrag vollständig erbracht und technisch abgeschlossen:',
                 done_items),
                ('C  LEISTUNGEN IN BEARBEITUNG',
                 'Die nachstehenden Leistungen wurden begonnen:',
                 inprogress_items),
                ('D  NOCH OFFENE LEISTUNGEN',
                 'Die nachstehenden Leistungen wurden noch nicht begonnen und werden gesondert abgerechnet:',
                 open_items),
            ]
        else:
            sections = [
                ('B  COMPLETED SERVICES',
                 'The following services have been fully completed according to contract:',
                 done_items),
                ('C  SERVICES IN PROGRESS',
                 'The following services have been started:',
                 inprogress_items),
                ('D  OPEN SERVICES',
                 'The following services have not yet been started and will be billed separately:',
                 open_items),
            ]

        for heading, intro, section_items in sections:
            pdf.add_section_heading(heading, intro)
            if section_items:
                pdf.add_performance_items_table(section_items, lang_upper)
            else:
                pdf.ln(2)
                pdf.set_font('Roboto', '', 9)
                pdf.multi_cell(0, 5, '-')

        # E ABRECHNUNGSGRUNDLAGE
        if pdf.get_y() > 250:
            pdf.add_page()
        pdf.ln(8)
        pdf.set_font('Roboto', 'B', 10)
        pdf.set_text_color(*pdf.color_black)
        pct = deposit_percent if deposit_percent else '0'
        if lang == 'de':
            pdf.cell(0, 6, 'E  ABRECHNUNGSGRUNDLAGE', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'Die Leistungen in Abschnitt B gelten mit Unterzeichnung als abgenommen und für die Endabrechnung '
                f'freigegeben. Für jede neu begonnene Leistung in Abschnitt C fällt eine Anzahlung in Höhe von {pct} % '
                'der veranschlagten Kosten an. Leistungen in Abschnitt D sind inhaltlich vereinbart, bedürfen jedoch '
                'noch der Beauftragung.')
        else:
            pdf.cell(0, 6, 'E  BASIS FOR INVOICING', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5,
                'The services in section B are considered accepted upon signing and released for final invoicing. '
                f'For each newly started service in section C, a deposit of {pct} % of the estimated costs is due. '
                'Services in section D have been agreed in terms of content but still require commissioning.')

        # F BESTÄTIGUNG
        if pdf.get_y() > 240:
            pdf.add_page()
        pdf.ln(8)
        pdf.set_font('Roboto', 'B', 10)
        if lang == 'de':
            pdf.cell(0, 6, 'F  BESTÄTIGUNG', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, 'Mit Unterzeichnung dieses Leistungsscheins bestätigt der Auftraggeber den dargestellten Leistungsstand:')
        else:
            pdf.cell(0, 6, 'F  CONFIRMATION', ln=True)
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, 'By signing this performance slip, the client confirms the stated service status:')

        # Signature lines
        pdf.ln(12)
        pdf.set_font('Roboto', '', 9)
        if lang == 'de':
            pdf.cell(75, 6, 'Ort, Datum: _____________________________')
            pdf.cell(15, 6, '')
            pdf.cell(0, 6, 'Unterschrift: _____________________________', ln=True)
        else:
            pdf.cell(75, 6, 'Place, Date: _____________________________')
            pdf.cell(15, 6, '')
            pdf.cell(0, 6, 'Signature: _____________________________', ln=True)

        # Closing greeting + sender info
        pdf.ln(10)
        pdf.set_font('Roboto', '', 9)
        pdf.multi_cell(0, 5, note)

        if closing_name:
            pdf.ln(8)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, closing_name)
        if closing_title:
            pdf.ln(1)
            pdf.set_font('Roboto', '', 9)
            pdf.multi_cell(0, 5, closing_title)
            pdf.multi_cell(0, 5, pdf.company_data['name'])

        pdf.output(filename)
        return filename

    # Leistungszeitraum
    if period:
        pdf.add_period(period)

    # Einleitungstext
    if pretext:
        pdf.add_pretext(pretext)
    
    # Tabellen-Header
    if lang == 'de':
        headers = ['Pos.', 'Beschreibung', 'Menge', 'Einzelpreis', 'Gesamt']
    else:
        headers = ['Pos.', 'Description', 'Quantity', 'Unit Price', 'Total']
    
    # Artikel-Tabelle formatieren
    formatted_items = []
    netsum = 0.0
    vat_amounts = {}

    lang_upper = language.upper()  # 'DE' oder 'EN'

    for idx, item in enumerate(items, start=1):
        # Support items that may include a status (performance_slip) as fifth element
        if len(item) >= 5:
            description, quantity, unit_price, vat_rate, _status = item
        else:
            description, quantity, unit_price, vat_rate = item
            _status = None
        total = round(quantity * unit_price, 2)  # ✅ Runden wie im alten Code
        netsum += total
        
        # MwSt sammeln
        if vat_rate != 0:
            if vat_rate not in vat_amounts:
                vat_amounts[vat_rate] = 0.0
            vat_amounts[vat_rate] += total * (vat_rate / 100)
        
        # ✅ Formatierung mit den neuen Funktionen
        formatted_items.append([
            str(idx),
            description,
            format_number(quantity, lang_upper),           # ✅ Entfernt .00 bei ganzen Zahlen
            format_currency(unit_price, lang_upper),       # ✅ Sprachabhängig
            format_currency(total, lang_upper),            # ✅ Sprachabhängig
        ])

    
    col_widths = pdf.add_items_table(formatted_items, headers)
    
    # ✅ SUMMEN MIT REVERSE-CHARGE LOGIK (wie im alten Code)
    totals = []
    
    # ✅ Netto-Summe (immer erste Zeile)
    if lang == 'de':
        totals.append(('Netto-Summe', format_currency(netsum, lang_upper)))
    else:
        totals.append(('Net', format_currency(netsum, lang_upper)))

    # ✅ Reverse Charge Unterscheidung
    if not reverse_charge:
        # MwSt-Zeilen hinzufügen (nur wenn NICHT reverse charge)
        for vat_rate in sorted(vat_amounts.keys()):
            vat_amount = round(vat_amounts[vat_rate], 2)  # ✅ Runden
            
            if lang == 'de':
                label = f"MwSt ({format_number(vat_rate, lang_upper)}%)"
            else:
                label = f"Vat ({format_number(vat_rate, lang_upper)}%)"
            
            totals.append((label, format_currency(vat_amount, lang_upper)))
        
        # Gesamtsumme (nur wenn NICHT reverse charge)
        grossSum = netsum + sum(vat_amounts.values())
        if lang == 'de':
            totals.append(('Gesamt', format_currency(grossSum, lang_upper)))
        else:
            totals.append(('Total', format_currency(grossSum, lang_upper)))

    
    y_start = pdf.get_y()
    pdf.add_totals_table(totals, col_widths, y_start)
    
    # Benutzerdefinierter Text (volle Seitenbreite)
    if custom_note:
        page_width = 210
        margin_left = 25
        margin_right = 20
        available_width = page_width - margin_left - margin_right

        pdf.ln(10)
        pdf.set_font('Roboto', size=9)
        pdf.set_text_color(*pdf.color_black)
        pdf.multi_cell(available_width, 5, custom_note)

    # Schlusstext (schmale Breite)
    pdf.add_note(note)

    # PDF speichern
    pdf.output(filename)
    
    return filename
