"""
Flask-Anwendung für Rechnungs- und Angebotserstellung
Optimierte Version mit DRY-Prinzip und Modularität
"""
from flask import Flask, render_template, request, jsonify
import json
import os
from typing import Dict, List, Any

from config import (
    FLASK_HOST, FLASK_PORT, FLASK_DEBUG,
    REVERSE_CHARGE_COUNTRIES, PDF_OUTPUT_DIR, RECIPIENTS_FILE
)
from utils import get_country_name, format_date, clean_multiline_string, build_contact_string
from document_types import get_document_type
from pdf_generator import create_document_pdf

# ✅ Stelle sicher, dass Output-Verzeichnis existiert
os.makedirs(PDF_OUTPUT_DIR, exist_ok=True)

app = Flask(__name__)


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def load_recipients() -> List[Dict]:
    """Lädt Empfänger aus JSON-Datei"""
    try:
        with open(RECIPIENTS_FILE, 'r', encoding='utf-8') as file:
            return json.load(file)
    except FileNotFoundError:
        return []


def save_recipients(recipients: List[Dict]):
    """Speichert Empfänger in JSON-Datei"""
    with open(RECIPIENTS_FILE, 'w', encoding='utf-8') as file:
        json.dump(recipients, file, indent=4, ensure_ascii=False)


def build_receiver_block(form_data: Dict, language: str) -> str:
    """
    Erstellt den Empfänger-Textblock aus Formulardaten
    
    Args:
        form_ Dictionary mit Formular-Daten
        language: 'de' oder 'en'
    
    Returns:
        Mehrzeiliger Empfänger-String
    """
    lines = []
    
    # Firma
    if form_data.get('receiver_firma'):
        lines.append(form_data['receiver_firma'])
    
    # Kontaktperson
    if form_data.get('receiver_contact-person'):
        lines.append(form_data['receiver_contact-person'])
    
    # Adresse
    if form_data.get('receiver_address'):
        lines.append(form_data['receiver_address'])
    
    # Adresszusatz
    if form_data.get('receiver_address-addition'):
        lines.append(form_data['receiver_address-addition'])
    
    # PLZ + Ort
    zip_code = form_data.get('receiver_zip', '')
    city = form_data.get('receiver_city', '')
    if zip_code or city:
        lines.append(f"{zip_code} {city}".strip())
    
    # Land
    country_code = form_data.get('receiver_country', '')
    if country_code:
        lines.append(get_country_name(country_code, language))
    
    # USt-ID
    ustid = form_data.get('receiver_ustid', '')
    if ustid:
        label = 'Ust.-Id.' if language == 'de' else 'VAT ID'
        lines.append(f"{label}: {ustid}")
    
    # Kontaktdaten (E-Mail | Telefon)
    email = form_data.get('receiver_email', '')
    phone = form_data.get('receiver_phone', '')
    contact = build_contact_string(email, phone)
    if contact:
        lines.append('')  # Leerzeile vor Kontakt
        lines.append(contact)
    
    return clean_multiline_string('\n'.join(lines))


def build_details_block(form_data: Dict, language: str, document_type_id: str) -> str:
    """
    Erstellt den Details-Textblock (rechts oben)
    
    Args:
        form_ Dictionary mit Formular-Daten
        language: 'de' oder 'en'
        document_type_id: 'invoice' oder 'offer'
    
    Returns:
        Mehrzeiliger Details-String
    """
    doc_type = get_document_type(document_type_id)
    fields = doc_type.fields_de if language == 'de' else doc_type.fields_en
    
    lines = []
    
    # Nummer
    number = form_data.get('invoice_number', '')
    lines.append(f"{fields['number']}: {number}")
    
    # Datum
    date = form_data.get('invoice_date', '')
    if date:
        formatted_date = format_date(date, language)
        lines.append(f"{fields['date']}: {formatted_date}")
    
    # Fälligkeit
    due = form_data.get('invoice_due', '')
    if due:
        formatted_due = format_date(due, language)
        lines.append(f"{fields['due']}: {formatted_due}")
    
    # Ansprechpartner
    contact = form_data.get('invoice_contact', '')
    if contact:
        lines.append(f"{fields['contact']}: {contact}")
    
    return clean_multiline_string('\n'.join(lines))


def build_period_text(form_data: Dict, language: str, document_type_id: str) -> str:
    """
    Erstellt den Leistungszeitraum-Text
    
    Args:
        form_ Dictionary mit Formular-Daten
        language: 'de' oder 'en'
        document_type_id: 'invoice' oder 'offer'
    
    Returns:
        Leistungszeitraum als String
    """
    doc_type = get_document_type(document_type_id)
    fields = doc_type.fields_de if language == 'de' else doc_type.fields_en
    
    date_from = form_data.get('invoice_from', '')
    date_till = form_data.get('invoice_till', '')
    
    if not date_from or not date_till:
        return ''
    
    formatted_from = format_date(date_from, language)
    formatted_till = format_date(date_till, language)
    
    if date_from == date_till:
        return f"{fields['period_single']}: {formatted_from}"
    else:
        return f"{fields['period_range']}: {formatted_from} - {formatted_till}"

def build_pretext(form_data: Dict, language: str, document_type_id: str) -> str:
    return form_data.get('invoice_text', '')

def build_note_text(form_data: Dict, language: str, reverse_charge: bool, document_type_id: str) -> str:
    """
    Erstellt den Abschluss-/Notiz-Text
    
    Args:
        form_ Dictionary mit Formular-Daten
        language: 'de' oder 'en'
        reverse_charge: Ob Reverse-Charge gilt
        document_type_id: 'invoice' oder 'offer'
    
    Returns:
        Notiz als String
    """
    doc_type = get_document_type(document_type_id)
    template = doc_type.note_template_de if language == 'de' else doc_type.note_template_en
    
    # Fälligkeitsdatum
    due_date = form_data.get('invoice_due', '')
    formatted_due = format_date(due_date, language, with_suffix=True) if due_date else ''
    
    # Reverse-Charge Text
    reverse_charge_text = ''
    if reverse_charge:
        if language == 'de':
            reverse_charge_text = (
                'Diese Rechnung unterliegt dem Reverse-Charge-Verfahren; '
                'der Empfänger ist für die Meldung der Umsatzsteuer verantwortlich.'
            )
        else:
            reverse_charge_text = (
                'This invoice is subject to the reverse charge mechanism; '
                'the recipient is responsible for reporting VAT.'
            )
    
    return template.format(due_date=formatted_due, reverse_charge=reverse_charge_text)


def build_filename(form_data: Dict, language: str, document_type_id: str) -> str:
    """
    Erstellt den Dateinamen für das PDF
    
    Args:
        form_ Dictionary mit Formular-Daten
        language: 'de' oder 'en'
        document_type_id: 'invoice' oder 'offer'
    
    Returns:
        Vollständiger Dateipfad
    """
    doc_type = get_document_type(document_type_id)
    prefix = doc_type.filename_prefix_de if language == 'de' else doc_type.filename_prefix_en
    
    number = form_data.get('invoice_number', 'XXX')
    company_name = form_data.get('receiver_firma', 'Unbekannt').strip()
    
    filename = f"{prefix} {number} - {company_name}.pdf"
    return f"{PDF_OUTPUT_DIR}/{filename}"


def parse_articles(form_data: Dict, document_type_id: str) -> List[List]:
    """
    Parst Artikel aus Formulardaten und unterstützt unterschiedliche Formate

    Für `invoice` und `offer` werden erwartet: art_name, art_count, art_price, art_vat
    Für `performance_slip` werden erwartet: art_name, art_description, art_price

    Liefert eine Liste von Listen im Format [description, quantity, unit_price, vat_rate]
    """
    articles = []

    # Normale Felder (können fehlen)
    art_names = form_data.get('art_name', []) or []
    art_descriptions = form_data.get('art_description', []) or []
    art_counts = form_data.get('art_count', []) or []
    art_prices = form_data.get('art_price', []) or []
    art_vats = form_data.get('art_vat', []) or []
    art_status = form_data.get('art_status', []) or []
    art_pos = form_data.get('art_pos', []) or []

    # Anzahl der Positionen basierend auf Namen (Fallback auf Preise/Status)
    length = max(len(art_names), len(art_prices), len(art_status))
    if length == 0:
        return []

    for i in range(length):
        name = art_names[i] if i < len(art_names) else ''
        desc = art_descriptions[i] if i < len(art_descriptions) else ''

        # Leistungsschein / Grobindikation: [pos, name, description, price, status]
        if document_type_id in ('performance_slip', 'rough_indication'):
            pos = art_pos[i] if i < len(art_pos) and art_pos[i] != '' else str(i + 1)
            name_field = name
            desc_field = desc
            try:
                unit_price = float(art_prices[i]) if i < len(art_prices) and art_prices[i] != '' else 0.0
            except Exception:
                unit_price = 0.0
            quantity = 1.0
            vat_rate = 0.0
        else:
            # Für Rechnung/Angebot: Beschreibung = Name (+ Beschreibung wenn vorhanden)
            description = name
            if desc:
                description = f"{name} — {desc}" if name else desc

            try:
                quantity = float(art_counts[i]) if i < len(art_counts) and art_counts[i] != '' else 1.0
            except Exception:
                quantity = 1.0

            try:
                unit_price = float(art_prices[i]) if i < len(art_prices) and art_prices[i] != '' else 0.0
            except Exception:
                unit_price = 0.0

            try:
                vat_rate = float(art_vats[i]) if i < len(art_vats) and art_vats[i] != '' else 0.0
            except Exception:
                vat_rate = 0.0

        # Status pro Position (bei Leistungsschein wichtig)
        status = art_status[i] if i < len(art_status) and art_status[i] != '' else 'open'

        if document_type_id in ('performance_slip', 'rough_indication'):
            articles.append([pos, name_field, desc_field, unit_price, status])
        else:
            articles.append([description, quantity, unit_price, vat_rate, status])

    return articles


def process_document_creation(form_data: Dict, document_type_id: str) -> Dict[str, str]:
    """
    Hauptlogik für Dokumenterstellung (DRY für Invoice und Offer)
    
    Args:
        form_ Dictionary mit Formular-Daten
        document_type_id: 'invoice' oder 'offer'
    
    Returns:
        Dictionary mit file_path und file_name
    """
    # Basisdaten extrahieren
    language = form_data.get('invoice_language', ['de'])[0].lower()
    company = form_data.get('invoice_company', ['gmbh'])[0].lower()
    
    # Formulardaten in flaches Dictionary umwandeln
    array_fields = ['art_name', 'art_count', 'art_price', 'art_vat', 'art_description', 'art_status', 'art_pos']
    flat_data = {}
    for key, value in form_data.items():
        if isinstance(value, list) and len(value) > 0 and key not in array_fields:
            flat_data[key] = value[0]
        else:
            flat_data[key] = value
    print(flat_data)

    # Reverse Charge prüfen
    receiver_country = flat_data.get('receiver_country', '')
    reverse_charge = receiver_country in REVERSE_CHARGE_COUNTRIES
    
    # Textblöcke erstellen
    receiver = build_receiver_block(flat_data, language)
    details = build_details_block(flat_data, language, document_type_id)
    period = build_period_text(flat_data, language, document_type_id)
    pretext = build_pretext(flat_data, language, document_type_id)
    note = build_note_text(flat_data, language, reverse_charge, document_type_id)

    # Optionaler benutzerdefinierter Text nach der Positionstabelle (vor dem Schlusstext)
    custom_note = flat_data.get('invoice_note', '')

    # Artikel parsen (Format kann je nach Dokumenttyp variieren)
    articles = parse_articles(form_data, document_type_id)
    
    # Dokumentnummer und Titel
    document_number = flat_data.get('invoice_number', '')
    document_title_suffix = flat_data.get('invoice_title', '')

    # Leistungsschein-/Grobindikation-spezifische Felder
    project_info = flat_data.get('project_description', '') if document_type_id in ('performance_slip', 'rough_indication') else ''
    closing_name = flat_data.get('closing_name', '') if document_type_id in ('performance_slip', 'rough_indication') else ''
    closing_title = flat_data.get('closing_title', '') if document_type_id in ('performance_slip', 'rough_indication') else ''
    deposit_percent = flat_data.get('deposit_percent', '') if document_type_id in ('performance_slip', 'rough_indication') else ''

    # Dateiname
    filename = build_filename(flat_data, language, document_type_id)

    # PDF erstellen
    doc_type = get_document_type(document_type_id)
    filepath = create_document_pdf(
        filename=filename,
        document_type=doc_type,
        company=company,
        language=language.upper(),
        receiver=receiver,
        document_number=document_number,
        document_title_suffix=document_title_suffix,
        details=details,
        period=period,
        pretext=pretext,
        items=articles,
        note=note,
        custom_note=custom_note,
        reverse_charge=reverse_charge,
        project_info=project_info,
        closing_name=closing_name,
        closing_title=closing_title,
        deposit_percent=deposit_percent,
    )
    
    return {
        'file_path': f"/{filepath}",
        'file_name': f"/{filename}"
    }


# ============================================================================
# ROUTES
# ============================================================================

@app.route('/', methods=['GET'])
def index():
    """Zeigt die Startseite"""
    return render_template('index.html', active_page='index')


@app.route('/rechnung', methods=['GET'])
def invoice_form():
    """Zeigt das Rechnungsformular"""
    recipients = load_recipients()
    return render_template('rechnungsdaten.html', recipients=json.dumps(recipients), active_page='rechnung')


@app.route('/angebot', methods=['GET'])
def offer_form():
    """Zeigt das Angebotsformular"""
    recipients = load_recipients()
    return render_template('angebotsdaten.html', recipients=json.dumps(recipients), active_page='angebot')


@app.route('/create-pdf', methods=['POST'])
def create_invoice_pdf():
    """Erstellt eine Rechnung als PDF"""
    print('📄 Rechnung wird erstellt...')
    data = request.form.to_dict(flat=False)
    result = process_document_creation(data, 'invoice')
    print(f'✅ Rechnung erstellt: {result["file_name"]}')
    return jsonify(result)


@app.route('/create-offer', methods=['POST'])
def create_offer_pdf():
    """Erstellt ein Angebot als PDF"""
    print('📄 Angebot wird erstellt...')
    data = request.form.to_dict(flat=False)
    result = process_document_creation(data, 'offer')
    print(f'✅ Angebot erstellt: {result["file_name"]}')
    return jsonify(result)


@app.route('/recipients', methods=['GET', 'POST'])
def recipients():
    """Verwaltet Empfänger"""
    if request.method == 'POST':
        recipients_data = request.json.get('recipients', [])
        save_recipients(recipients_data)
        return jsonify({"message": "Daten erfolgreich gespeichert!"})
    
    recipients_data = load_recipients()
    return render_template('recipients.html', recipients=recipients_data, active_page='recipients')


@app.route('/addrecipient', methods=['POST'])
def add_recipient():
    """Fügt neuen Empfänger hinzu"""
    new_recipient = request.json
    
    recipients_data = load_recipients()
    
    # Automatische ID-Berechnung
    new_id = max([r['id'] for r in recipients_data], default=0) + 1
    new_recipient['id'] = new_id
    
    recipients_data.append(new_recipient)
    save_recipients(recipients_data)
    
    return jsonify({"message": "Empfänger erfolgreich hinzugefügt!", "id": new_id})


@app.route('/gutschrift', methods=['GET'])
def credit_note_form():
    """Zeigt das Gutschriftsformular"""
    recipients = load_recipients()
    return render_template('gutschriftsdaten.html', recipients=json.dumps(recipients), active_page='gutschrift')


@app.route('/create-credit-note', methods=['POST'])
def create_credit_note_pdf():
    """Erstellt eine Gutschrift als PDF"""
    print('📄 Gutschrift wird erstellt...')
    data = request.form.to_dict(flat=False)
    result = process_document_creation(data, 'credit_note')
    print(f'✅ Gutschrift erstellt: {result["file_name"]}')
    return jsonify(result)


@app.route('/leistungsschein', methods=['GET'])
def performance_slip_form():
    """Zeigt das Leistungsschein-Formular"""
    recipients = load_recipients()
    return render_template('leistungsscheindaten.html', recipients=json.dumps(recipients), active_page='leistungsschein')


@app.route('/create-performance-slip', methods=['POST'])
def create_performance_slip_pdf():
    """Erstellt einen Leistungsschein als PDF"""
    print('📄 Leistungsschein wird erstellt...')
    data = request.form.to_dict(flat=False)
    result = process_document_creation(data, 'performance_slip')
    print(f'✅ Leistungsschein erstellt: {result["file_name"]}')
    return jsonify(result)


@app.route('/grobindikation', methods=['GET'])
def rough_indication_form():
    """Zeigt das Grobindikation-Formular"""
    recipients = load_recipients()
    return render_template('grobindikation.html', recipients=json.dumps(recipients), active_page='grobindikation')


@app.route('/create-rough-indication', methods=['POST'])
def create_rough_indication_pdf():
    """Erstellt eine Grobindikation als PDF"""
    print('📄 Grobindikation wird erstellt...')
    data = request.form.to_dict(flat=False)
    result = process_document_creation(data, 'rough_indication')
    print(f'✅ Grobindikation erstellt: {result["file_name"]}')
    return jsonify(result)


# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    LOCOHOSTO='127.0.0.1'
    print("=" * 60)
    print("🚀 HotelFriend Invoice System")
    print("=" * 60)
    print(f"📍 Server läuft auf: http://{FLASK_HOST}:{FLASK_PORT}")
    print(f"🏠 Startseite: http://{LOCOHOSTO}:{FLASK_PORT}/")
    print(f"📄 Rechnung: http://{LOCOHOSTO}:{FLASK_PORT}/rechnung")
    print(f"📄 Angebot: http://{LOCOHOSTO}:{FLASK_PORT}/angebot")
    print(f"📄 Gutschrift: http://{LOCOHOSTO}:{FLASK_PORT}/gutschrift")
    print(f"📄 Leistungsschein: http://{LOCOHOSTO}:{FLASK_PORT}/leistungsschein")
    print(f"📄 Grobindikation: http://{LOCOHOSTO}:{FLASK_PORT}/grobindikation")
    print(f"👥 Empfänger: http://{LOCOHOSTO}:{FLASK_PORT}/recipients")
    print("=" * 60)
    
    app.run(host=FLASK_HOST, port=FLASK_PORT, debug=FLASK_DEBUG)
