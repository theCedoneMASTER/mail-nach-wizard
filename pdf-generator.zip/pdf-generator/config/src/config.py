"""
Zentrale Konfigurationsdatei für das Invoice-Projekt
"""

# Firmen-Konfigurationen
COMPANIES = {
    'gmbh': {
        'name': 'HotelFriend Service GmbH',
        'address': 'Friedrichstraße 171',
        'zip': '10117',
        'city': 'Berlin',
        'country': 'Deutschland',
        'logo': 'sources/logo-gmbh.png',
        'sender_line_de': 'HotelFriend Service GmbH - Friedrichstraße 171 - 10117 Berlin',
        'sender_line_en': 'HotelFriend Service GmbH - Friedrichstraße 171 - 10117 Berlin',
    },
    'ag': {
        'name': 'HotelFriend AG',
        'address': 'Friedrichstraße 171',
        'zip': '10117',
        'city': 'Berlin',
        'country': 'Deutschland',
        'logo': 'sources/logo-ag.png',
        'sender_line_de': 'HotelFriend AG - Friedrichstraße 171 - 10117 Berlin',
        'sender_line_en': 'HotelFriend AG - Friedrichstraße 171 - 10117 Berlin',
    }
}

# PDF-Farben (RGB)
COLORS = {
    'black': (0, 0, 0),
    'dark_blue': (84, 94, 123),
    'light_blue': (158, 203, 237),
    'white': (255, 255, 255),
}

# Reverse-Charge Länder (ISO-2 Codes)
REVERSE_CHARGE_COUNTRIES = [
    "CH", "AT", "GB", "AU", "BE", "BG", "CN", "DK", "EE", "FI", "FR", "GR",
    "IE", "IS", "IT", "HR", "LV", "LI", "LT", "LU", "MT", "NL", "NO", "PL",
    "PT", "RO", "SE", "SI", "SK", "ES", "CZ", "TR", "HU", "CY"
]

# Pfade
PDF_OUTPUT_DIR = 'static'
FONTS_DIR = 'sources'
RECIPIENTS_FILE = 'recipients.json'

# Flask-Konfiguration
FLASK_HOST = '0.0.0.0'
FLASK_PORT = 5030
FLASK_DEBUG = True
