# 📋 HotelFriend Invoice System – Projekt-Dokumentation

## 🎯 Projektübersicht

**Zweck:** Webfrontend zur Erstellung und PDF-Vorlage für Rechnungen und Angebote  
**Tech-Stack:** Flask (Backend) + HTML/Bulma (Frontend) + FPDF (PDF-Generator)  
**Sprachen:** Deutsch & Englisch (komplett mehrsprachig)  
**Firmen:** 2 Varianten (GmbH & AG)

---

## 📂 Projektstruktur & Dateiübersicht

```
pdfinvoiceperplexity/
├── app.py                          # Flask-Hauptanwendung & Routes
├── config.py                       # Zentrale Konfiguration (Firmen, Farben, Pfade)
├── document_types.py               # Dokumenttypen (Rechnung, Angebot) mit Texttemplates
├── pdf_generator.py                # Hauptfunktion zum PDF-Generieren
├── pdf_generator_nofooter.py       # Alternative ohne Footer (veraltet/experimental)
├── utils.py                        # Hilfsfunktionen (Daten, Datum, Länder, Format)
├── recipients.json                 # Gespeicherte Empfänger-Datenbank
├── requirements.txt                # Python-Dependencies
│
├── templates/                      # HTML-Templates (Bulma CSS)
│   ├── rechnungsdaten.html        # Formular für Rechnungserstellung
│   ├── angebotsdaten.html         # Formular für Angebotserstellung
│   └── recipients.html            # Verwaltung der Empfänger-Datenbank
│
├── static/                         # Output-Verzeichnis für generierte PDFs
│   └── [generierte PDF-Dateien]
│
└── sources/                        # Statische Assets
    ├── logo-gmbh.png
    ├── logo-ag.png
    └── Roboto-*.ttf               # Font-Dateien (Light, LightItalic, Medium)
```

---

## 🔧 Abhängigkeiten

```
Flask==3.0.0              # Web-Framework
fpdf==1.7.2               # PDF-Generator
pycountry==23.12.11       # Ländercode & -namen
Babel==2.14.0             # Lokalisierung & Datum-Formatierung
```

---

## 📜 Core-Module – Detaillierte Übersicht

### 1️⃣ **app.py** – Flask-Anwendung & Request-Handling

**Hauptfunktionen:**
- **`load_recipients()` / `save_recipients()`** → Lädt/speichert Empfänger aus recipients.json
- **`build_receiver_block()`** → Erstellt Empfänger-Adressblock aus Formulardaten
- **`build_details_block()`** → Details-Block rechts oben (Nummer, Datum, Fälligkeit)
- **`build_period_text()`** → Leistungszeitraum-Text (z.B. "01.01.2024 - 31.01.2024")
- **`build_note_text()`** → Schlusstext mit Reverse-Charge-Logik
- **`build_filename()`** → Generiert Dateinamen (z.B. "Rechnung 2024-001 - Firma.pdf")
- **`parse_articles()`** → Konvertiert Artikel-Arrays aus Formular
- **`process_document_creation()`** → **Zentrale DRY-Funktion** für Rechnung & Angebot

**Flask-Routes:**
```python
GET  /rechnung       → Rechnungsformular anzeigen
GET  /angebot        → Angebotsformular anzeigen
POST /create-pdf     → Rechnung generieren
POST /create-offer   → Angebot generieren
GET  /recipients     → Empfänger-Management
POST /addrecipient   → Neuen Empfänger hinzufügen
```

---

### 2️⃣ **config.py** – Zentrale Konfiguration

**COMPANIES-Dictionary:** Definiert 2 Firmen-Varianten
```python
{
    'gmbh': { name, address, city, logo, sender_line_de, sender_line_en, ... },
    'ag':   { name, address, city, logo, sender_line_de, sender_line_en, ... }
}
```

**REVERSE_CHARGE_COUNTRIES:** Liste von Ländern, bei denen Reverse-Charge gilt (z.B. CH, AT, GB)

**COLORS:** RGB-Farben für PDF-Elemente (dark_blue, light_blue, black, white)

**Pfade:**
- `PDF_OUTPUT_DIR = 'static'` → Wo werden generierte PDFs gespeichert?
- `FONTS_DIR = 'sources'` → Wo sind die Font-Dateien?
- `RECIPIENTS_FILE = 'recipients.json'` → Empfänger-Datenbank

---

### 3️⃣ **document_types.py** – Dokumenttypen-Definitionen

**DocumentType Dataclass:** Definiert das "Template" für einen Dokumenttyp

```python
@dataclass
class DocumentType:
    type_id              # 'invoice' oder 'offer'
    title_de / title_en  # Titel-Template (z.B. "Rechnung Nr. {number}")
    fields_de / fields_en # Label-Dictionary (Rechnungsdatum, Fälligkeit, etc.)
    note_template_de / note_template_en # Schlusstext-Template
    filename_prefix_de / filename_prefix_en # Dateinamen-Präfix
```

**Vordefinierte Typen:**
- `INVOICE` – Rechnung (mit Zahlungsaufforderung)
- `OFFER` – Angebot (ohne Zahlungsaufforderung, höflich)

→ **Hier neue Dokumenttypen hinzufügen** (z.B. Lieferschein, Gutschrift)

---

### 4️⃣ **utils.py** – Hilfsfunktionen

| Funktion | Zweck |
|----------|-------|
| `get_country_name(code, lang)` | Konvertiert ISO-2 Land zu Ländername |
| `format_date(iso_date, lang, with_suffix)` | ISO-Datum → "01.01.2024" oder "1st January 2024" |
| `format_currency(amount, currency)` | Geldbetrag formatieren mit Währung |
| `build_contact_string(*parts)` | Verbindet E-Mail/Telefon mit " \| " |
| `clean_multiline_string(text)` | Entfernt führende/nachfolgende Leerzeilen |

---

### 5️⃣ **pdf_generator.py** – PDF-Kern

**DocumentPDF Klasse** (erweitert FPDF):

**Struktur-Methoden:**
- `header()` → Logo + Kopflinie auf jeder Seite
- `footer()` → Firmendaten-Tabelle (4 Spalten, Größe 6pt)
- `add_receiver_block()` → Adressblock links
- `add_details_block()` → Details rechts (Nummer, Datum, etc.)
- `add_document_title()` → Titel (z.B. "Rechnung Nr. 2024-001")
- `add_period()` → Leistungszeitraum
- `add_items_table()` → Artikel-Tabelle mit intelligenter Zeilenumbruch
- `add_totals_table()` → Summen-Tabelle (Netto, MwSt, Gesamt)
- `add_note()` → Schlusstext

**Formatierungs-Funktionen:**
- `format_number(num, lang)` → Zahl sprachabhängig (1000 → "1.000" DE, "1,000" EN)
- `format_currency(num, lang, currency)` → Währung mit 2 Dezimalstellen

**Haupt-Funktion:**
```python
create_document_pdf(
    filename, document_type, company, language,
    receiver, document_number, document_title_suffix,
    details, period, pretext, items, note, reverse_charge
) → str (filepath)
```

→ **Diese Funktion ist die zentrale Fabrik für alle PDFs!**

---

### 6️⃣ **recipients.json** – Empfänger-Datenbank

```json
{
    "id": 1,
    "name": "Firmenname",
    "contact_person": "Name",
    "email": "mail@example.com",
    "phone": "+49...",
    "address": "Straße 1",
    "address_addition": "Gebäude B",
    "zip": "10117",
    "city": "Berlin",
    "country": "DE",
    "ustid": "DE123456789"
}
```

---

## 🌐 Frontend – HTML-Templates

### **rechnungsdaten.html** (702 Zeilen)
Formular für Rechnungserstellung:
- **Rechnungssteller-Sektion:** Nummer, Firma (GmbH/AG)
- **Empfänger-Sektion:** Dropdown mit gespeicherten Empfängern + Einzelfelder
- **Datums-Felder:** Rechnungsdatum, Fälligkeit, Leistungszeitraum
- **Artikel-Tabelle:** Dynamisch hinzufügbare Zeilen (Position, Beschreibung, Menge, Preis, MwSt)
- **Summen:** Automatische Berechnung im Frontend

### **angebotsdaten.html**
Identisch zu Rechnung, aber:
- Labels angebots-spezifisch (Angebotsdatum, gültig bis)
- Leistungszeitraum statt Fälligkeit

### **recipients.html**
Verwaltungs-Interface:
- Tabelle mit allen Empfängern
- Inline-Bearbeitung
- Hinzufügen/Löschen

---

## 🔄 Workflow – Von Formular zu PDF

```
1. User öffnet /rechnung → rechnungsdaten.html wird geladen
2. User füllt Formular & klickt "PDF generieren"
3. JavaScript sendet Form-Daten via POST /create-pdf
4. app.py ruft process_document_creation() auf
5. Formulardaten werden in "flaches" Dictionary konvertiert
6. Textblöcke (Adresse, Details, Summen) werden gebaut
7. create_document_pdf() wird aufgerufen
8. PDF wird mit DocumentPDF generiert & als "Rechnung XXXX - Firma.pdf" gespeichert
9. JSON-Response mit Dateipfad wird an Frontend gesendet
10. Browser leitet automatisch zu PDF weiter (Download)
```

---

## 💡 Wichtige Features & Logik

### ✅ **DRY-Prinzip**
- `process_document_creation()` wird für Rechnungen UND Angebote verwendet
- Dokumenttypen sind vollständig austauschbar über `get_document_type(type_id)`
- Keine Code-Duplizierung zwischen Rechnung und Angebot

### ✅ **Reverse-Charge-Verfahren**
```python
# Wenn Empfänger aus bestimmtem Land, wird automatisch:
- MwSt-Zeilen NICHT angezeigt (nur Netto)
- Hinweis im Schlusstext hinzugefügt
- "Reverse Charge applies" Logik
```

### ✅ **Mehrsprachigkeit**
- Sprache wählbar im Formular (DE/EN)
- Alle Feldlabels, Daten-Formate, Währungen sind sprachabhängig
- Verwendung von `Babel` für korrekte Datums-Formatierung

### ✅ **Artikel-Tabelle mit intelligenter Formatierung**
- `_split_text_into_lines()` bricht lange Beschreibungen automatisch um
- Abstände zwischen Zeilen dynamisch (4mm innerhalb eines Artikels, 6mm zwischen Artikeln)
- Formatierung mit sprachabhängigen Zahlen-Formaten

---

## 🛠️ Architektur-Diagramm

```
┌─────────────────────────────────────────────────────────┐
│                   Frontend (HTML)                        │
│  rechnungsdaten.html / angebotsdaten.html               │
└─────────────────────────────────────────────────────────┘
                    ↓ (Form-Daten)
┌─────────────────────────────────────────────────────────┐
│                  app.py (Flask)                          │
│  /rechnung, /angebot, /create-pdf, /recipients          │
└─────────────────────────────────────────────────────────┘
         ↓ (process_document_creation)
┌─────────────────────────────────────────────────────────┐
│            Datenverarbeitung & Builder                   │
│  build_receiver_block() → build_details_block()         │
│  build_period_text() → build_note_text() → ...          │
└─────────────────────────────────────────────────────────┘
              ↓ (create_document_pdf)
┌─────────────────────────────────────────────────────────┐
│         pdf_generator.py (DocumentPDF Klasse)           │
│  Header, Empfänger, Artikel-Tabelle, Summen, Footer    │
└─────────────────────────────────────────────────────────┘
              ↓ (PDF.output)
┌─────────────────────────────────────────────────────────┐
│           PDF in /static/ gespeichert                    │
│  "Rechnung 2024-001 - Firma.pdf"                        │
└─────────────────────────────────────────────────────────┘
```

---

## 🚀 Installation & Start

```bash
# Package installieren
pip install -r requirements.txt

# Flask-App starten
python app.py

# Öffne Browser
# http://localhost:5030/rechnung
# http://localhost:5030/angebot
# http://localhost:5030/recipients
```

---

## 🔍 Debugging & Häufige Issues

| Problem | Ursache | Lösung |
|---------|--------|--------|
| Fonts laden nicht | `sources/Roboto-*.ttf` fehlt | Überprüfe `FONTS_DIR` in config.py |
| Reverse Charge nicht erkannt | Land nicht in `REVERSE_CHARGE_COUNTRIES` | config.py aktualisieren |
| PDFs speichern nicht | static existiert nicht | `mkdir static/` erstellen |
| Empfänger laden nicht | recipients.json ungültiges JSON | Mit `json.tool` validieren |
| Lange Beschreibungen umbrechen falsch | `_split_text_into_lines()` Logik | `char_width` in pdf_generator.py anpassen |

---

## 📝 Erweiterungspunkte

### Neuen Dokumenttyp hinzufügen:
1. Neuen `DocumentType` in document_types.py definieren
2. Im Frontend einen Route `/neutyp` hinzufügen
3. Eine neue HTML-Template erstellen
4. In app.py neu Route mit `process_document_creation(data, 'neutyp')` aufrufen

### Neue Firma hinzufügen:
1. `COMPANIES['newcompany']` in config.py hinzufügen
2. Logo-Datei in sources speichern
3. Footer-Daten in `_get_footer_data()` in pdf_generator.py hinzufügen

### Neue Länder für Reverse Charge:
1. ISO-2 Code zu `REVERSE_CHARGE_COUNTRIES` in config.py hinzufügen

---

## 📊 Dateigrößen & Performance

| Datei | Größe | Komplexität |
|-------|-------|------------|
| app.py | 411 Zeilen | Mittel |
| pdf_generator.py | 648 Zeilen | Hoch (FPDF-Logik) |
| pdf_generator_nofooter.py | 398 Zeilen | Veraltet (Alternative) |
| rechnungsdaten.html | 702 Zeilen | Mittel |
| recipients.json | ~10KB | Gering |

---

## ✨ Zusammenfassung

Dieses Projekt ist ein **modular aufgebautes PDF-Invoice-System** mit:
- ✅ Vollständiger Mehrsprachigkeit (DE/EN)
- ✅ DRY-Prinzip mit zentraler `process_document_creation()`
- ✅ Flexible Dokumenttypen (Rechnung, Angebot, erweiterbar)
- ✅ Reverse-Charge-Verfahren für internationales Handling
- ✅ Speicherte Empfänger-Datenbank
- ✅ Professionelles FPDF-Layout mit Logos & Footer

**Für zukünftige Änderungen:** Beginne immer mit config.py (zentrale Quelle), dann app.py (Logik), dann pdf_generator.py (Rendering).

---
