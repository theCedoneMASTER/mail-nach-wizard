"""
Definitionen für verschiedene Dokumenttypen (Rechnung, Angebot, etc.)
"""
from dataclasses import dataclass
from typing import Dict


@dataclass
class DocumentType:
    """Definiert die Texte und Eigenschaften eines Dokumenttyps"""
    
    # Interne Identifier
    type_id: str
    
    # Dokumenttitel
    title_de: str
    title_en: str
    
    # Feld-Labels (für PDF)
    fields_de: Dict[str, str]
    fields_en: Dict[str, str]
    
    # Standardtexte
    note_template_de: str
    note_template_en: str
    
    # Dateinamen-Präfix
    filename_prefix_de: str
    filename_prefix_en: str


# Dokumenttyp: Rechnung
INVOICE = DocumentType(
    type_id='invoice',
    title_de='Rechnung Nr. {number}',
    title_en='Invoice No. {number}',
    fields_de={
        'number': 'Rechnungsnummer',
        'date': 'Rechnungsdatum',
        'due': 'Fälligkeit',
        'contact': 'Ansprechpartner',
        'period_single': 'Leistungsdatum',
        'period_range': 'Leistungszeitraum',
        'vat_id': 'Ust.-Id.',
    },
    fields_en={
        'number': 'Invoice Number',
        'date': 'Invoice Date',
        'due': 'Due Date',
        'contact': 'Contact Person',
        'period_single': 'Service Date',
        'period_range': 'Service Period',
        'vat_id': 'VAT ID',
    },
    note_template_de=(
        'Bitte überweisen Sie den Gesamtbetrag unter Angabe der Rechnungsnummer '
        'bis zum {due_date} auf unser Bankkonto.\n{reverse_charge}'
        '\nVielen Dank für Ihre Bestellung!'
    ),
    note_template_en=(
        'Please transfer the total amount to our bank account, specifying the invoice number, '
        'until {due_date}.\n{reverse_charge}'
        '\nThank you for your order!'
    ),
    filename_prefix_de='Rechnung',
    filename_prefix_en='Invoice',
)


# Dokumenttyp: Angebot
OFFER = DocumentType(
    type_id='offer',
    title_de='Angebot Nr. {number}',
    title_en='Offer No. {number}',
    fields_de={
        'number': 'Angebotsnummer',
        'date': 'Angebotsdatum',
        'due': 'gültig bis',
        'contact': 'Ansprechpartner',
        'period_single': 'Leistungsdatum',
        'period_range': 'Leistungszeitraum',
        'vat_id': 'Ust.-Id.',
    },
    fields_en={
        'number': 'Offer Number',
        'date': 'Offer Date',
        'due': 'valid till',
        'contact': 'Contact Person',
        'period_single': 'Service Date',
        'period_range': 'Service Period',
        'vat_id': 'VAT ID',
    },
    note_template_de=(
        'Wir freuen uns, wenn dieses Angebot Ihre Zustimmung findet.\nBei Rückfragen stehen wir selbstverständlich jederzeit gerne zur Verfügung!'
    ),
    note_template_en=(
        'We hope this offer meets your expectations.\nIf you have any questions, please feel free to reach out at any time — we’re happy to help!'
    ),
    filename_prefix_de='Angebot',
    filename_prefix_en='Offer',
)

# Dokumenttyp: Leistungsschein
PERFORMANCE_SLIP = DocumentType(
    type_id='performance_slip',
    title_de='Leistungsschein Nr. {number}',
    title_en='Performance Slip No. {number}',
    fields_de={
        'number': 'Leistungsscheinnummer',
        'date': 'Ausstellungsdatum',
        'due': 'Gültig bis',
        'contact': 'Ansprechpartner',
        'period_single': 'Leistungsdatum',
        'period_range': 'Leistungszeitraum',
        'vat_id': 'Ust.-Id.',
    },
    fields_en={
        'number': 'Performance Slip Number',
        'date': 'Issue Date',
        'due': 'Valid till',
        'contact': 'Contact Person',
        'period_single': 'Service Date',
        'period_range': 'Service Period',
        'vat_id': 'VAT ID',
    },
    note_template_de='Mit freundlichen Grüßen',
    note_template_en='Kind regards',
    filename_prefix_de='Leistungsschein',
    filename_prefix_en='Performance_Slip',
)

# Dokumenttyp: Gutschrift
CREDIT_NOTE = DocumentType(
    type_id='credit_note',
    title_de='Gutschrift Nr. {number}',
    title_en='Credit Note No. {number}',
    fields_de={
        'number': 'Gutschriftnummer',
        'date': 'Gutschriftsdatum',
        'due': 'Erstattung bis',
        'contact': 'Ansprechpartner',
        'period_single': 'Leistungsdatum',
        'period_range': 'Leistungszeitraum',
        'vat_id': 'Ust.-Id.',
    },
    fields_en={
        'number': 'Credit Note Number',
        'date': 'Credit Note Date',
        'due': 'Refund by',
        'contact': 'Contact Person',
        'period_single': 'Service Date',
        'period_range': 'Service Period',
        'vat_id': 'VAT ID',
    },
    note_template_de=(
        'Der Betrag wird Ihrem Konto gutgeschrieben.\n{reverse_charge}'
    ),
    note_template_en=(
        'The amount will be credited to your account.\n{reverse_charge}'
    ),
    filename_prefix_de='Gutschrift',
    filename_prefix_en='Credit_Note',
)

# Dokumenttyp: Grobindikation
ROUGH_INDICATION = DocumentType(
    type_id='rough_indication',
    title_de='Grobindikation Nr. {number}',
    title_en='Rough Indication No. {number}',
    fields_de={
        'number': 'Grobindikationsnummer',
        'date': 'Ausstellungsdatum',
        'due': 'Gültig bis',
        'contact': 'Ansprechpartner',
        'period_single': 'Leistungsdatum',
        'period_range': 'Leistungszeitraum',
        'vat_id': 'Ust.-Id.',
    },
    fields_en={
        'number': 'Indication Number',
        'date': 'Issue Date',
        'due': 'Valid till',
        'contact': 'Contact Person',
        'period_single': 'Service Date',
        'period_range': 'Service Period',
        'vat_id': 'VAT ID',
    },
    note_template_de='Mit freundlichen Grüßen',
    note_template_en='Kind regards',
    filename_prefix_de='Grobindikation',
    filename_prefix_en='Rough_Indication',
)

# Dokumenttypen-Registry
DOCUMENT_TYPES = {
    'invoice': INVOICE,
    'offer': OFFER,
    'performance_slip': PERFORMANCE_SLIP,
    'credit_note': CREDIT_NOTE,
    'rough_indication': ROUGH_INDICATION,
}


def get_document_type(type_id: str) -> DocumentType:
    """Gibt den Dokumenttyp zurück oder wirft Fehler"""
    if type_id not in DOCUMENT_TYPES:
        raise ValueError(f"Unbekannter Dokumenttyp: {type_id}")
    return DOCUMENT_TYPES[type_id]


