# PDF-Generator – Projektstand

Stand: 2026-03-17

## Übersicht

Flask-Webanwendung zur Erzeugung von Geschäftsdokumenten als PDF. Unterstützt 5 Dokumenttypen in 2 Sprachen für 2 Firmen. Nur im lokalen Büro-Netz erreichbar.

## Architektur

### Services (1 Container)

| Dienst | Image | Port | Rolle |
|---|---|---|---|
| **PDF-Generator** | Custom (Python 3.13 Slim) | 5030 | Flask-App mit Gunicorn (2 Worker, 120s Timeout) |

### Volumes (1)

| Volume | Zweck |
|---|---|
| pdf_output | Generierte PDFs (gemappt auf `/app/static`) |

Zusätzlich: `recipients.json` als Bind-Mount für Empfängerverwaltung.

## Anwendung

### Tech-Stack

- **Runtime:** Python 3.13 (Slim)
- **Framework:** Flask 3.0
- **PDF-Bibliothek:** fpdf 1.7.2
- **Lokalisierung:** Babel 2.14, pycountry 23.12
- **Production:** Gunicorn
- **Frontend:** Bulma CSS Framework

### Dokumenttypen (5)

| Typ | Route (Form) | Route (PDF) | Prefix DE | Prefix EN |
|---|---|---|---|---|
| Rechnung | `/rechnung` | `/create-pdf` | Rechnung | Invoice |
| Angebot | `/angebot` | `/create-offer` | Angebot | Offer |
| Gutschrift | `/gutschrift` | `/create-credit-note` | Gutschrift | Credit_Note |
| Leistungsschein | `/leistungsschein` | `/create-performance-slip` | Leistungsschein | Performance_Slip |
| Grobindikation | `/grobindikation` | `/create-rough-indication` | Grobindikation | Rough_Indication |

### Zusätzliche Routen

| Route | Methode | Funktion |
|---|---|---|
| `/` | GET | Startseite mit Übersicht aller Dokumenttypen |
| `/recipients` | GET | Empfängerverwaltung anzeigen |
| `/recipients` | POST | Empfängerliste speichern |
| `/addrecipient` | POST | Neuen Empfänger hinzufügen |

### Firmen

| ID | Name | Adresse |
|---|---|---|
| `gmbh` | HotelFriend Service GmbH | Friedrichstraße 171, 10117 Berlin |
| `ag` | HotelFriend AG | Friedrichstraße 171, 10117 Berlin |

Jeweils mit eigenem Logo, eigenen Fußzeilen-Daten (Bank, IBAN, Steuernummer) und Absenderzeilen (DE/EN).

### Sprachen

Vollständig zweisprachig (Deutsch/Englisch):
- Dokumenttitel, Feldbezeichnungen, Abschlusstexte
- Zahlenformatierung (DE: 1.000,50 / EN: 1,000.50)
- Datumsformatierung (DE: 17.03.2026 / EN: 17th March 2026)
- Ländernamen (via pycountry)

### Reverse Charge

Automatische Erkennung für 33 Länder (CH, AT, GB, FR, IT, u.a.). Bei Reverse Charge:
- Keine MwSt berechnet
- Hinweistext im Abschluss eingefügt
- USt-IdNr. des Empfängers angezeigt

### Artikel-Formate

**Rechnung, Angebot, Gutschrift:**
- Spalten: Beschreibung, Menge, Einzelpreis, MwSt-Satz
- Optionale Felder: Beschreibung (Zusatztext), Status

**Leistungsschein, Grobindikation:**
- Spalten: Position, Titel, Beschreibung, Kosten, Status
- Status: open, in_progress, done
- Gruppierung nach Status in Sektionen

### Leistungsschein – Sektionen

- A: Projektbeschreibung
- B: Erbrachte Leistungen (Status: done)
- C: In Bearbeitung (Status: in_progress)
- D: Noch offen (Status: open)
- E: Abrechnungsgrundlage (Anzahlungsprozent)
- F: Bestätigung (Unterschriftsfelder)

### Grobindikation – Sektionen

- A: Ressourcen (Team-Zusammensetzung)
- B: Leistungspositionen (Items mit Status)
- C: Erfüllung und Lieferung
- D: Zahlungsbedingungen
- E: AGB
- F: Sonstiges

### PDF-Layout

- **Header:** Firmen-Logo (rechts oben) + horizontale Linie
- **Empfänger:** DIN-Fenster-Position mit Absenderzeile (8pt) + Empfängeradresse
- **Details:** Rechtsbündig (Nummer, Datum, Fälligkeit, Kundennummer)
- **Tabelle:** 5-spaltig mit blauer Header-Zeile
- **Summen:** Netto, MwSt pro Satz, Gesamt
- **Footer:** 6-zeilige Tabelle mit Firmendaten, Bank, IBAN, Steuernummer
- **Font:** Roboto (Light, LightItalic, Medium)

### Empfängerverwaltung

23 vordefinierte Empfänger in `recipients.json` mit:
- Name, Ansprechpartner, E-Mail, Telefon
- Adresse (Straße, Zusatz, PLZ, Stadt)
- Land (ISO-2-Code), USt-IdNr.

Empfänger aus der Branche Hospitality/Tourismus: AGL, River Advice, KD, TUI, DFB, Noovy, u.a.

## Konfigurationsdateien

| Datei | Zweck |
|---|---|
| `docker-compose.yml` | 1 Service, 1 Volume |
| `.env.example` | Port-Konfiguration |
| `config/Dockerfile` | Python 3.13 Slim + Gunicorn |
| `config/src/app.py` | Flask-Routen und Formularverarbeitung |
| `config/src/config.py` | Firmendaten, Farben, Pfade, Reverse-Charge-Länder |
| `config/src/document_types.py` | 5 Dokumenttyp-Definitionen (Titel, Felder, Templates) |
| `config/src/pdf_generator.py` | DocumentPDF-Klasse (FPDF-Erweiterung) |
| `config/src/utils.py` | Hilfsfunktionen (Datum, Währung, Länder) |
| `config/src/recipients.json` | 23 vordefinierte Empfänger |
| `config/src/sources/` | Roboto-Fonts (3 Varianten) + Logos (GmbH, AG) |
| `config/src/templates/` | 8 Flask-HTML-Templates (Bulma CSS) |

### HTML-Templates

| Template | Funktion |
|---|---|
| `base.html` | Basis-Layout mit Navbar und HotelFriend-Branding |
| `index.html` | Startseite mit 6 Karten |
| `rechnungsdaten.html` | Rechnungsformular |
| `angebotsdaten.html` | Angebotsformular |
| `gutschriftsdaten.html` | Gutschriftsformular |
| `leistungsscheindaten.html` | Leistungsschein-Formular |
| `grobindikation.html` | Grobindikations-Formular |
| `recipients.html` | Empfängerverwaltung |

## Dokumentation

| Datei | Inhalt |
|---|---|
| `docs/anleitung-pdf-generator.html` | Vollständige Anleitung (HTML-Slideshow) |

## Status

### Erledigt

- [x] Flask-App fertig (5 Dokumenttypen: Rechnung, Angebot, Gutschrift, Leistungsschein, Grobindikation)
- [x] Zweisprachig (Deutsch/Englisch)
- [x] Zwei Firmen (GmbH/AG) mit eigenen Logos und Fußzeilen
- [x] Reverse-Charge-Logik (33 Länder)
- [x] Empfängerverwaltung (23 vordefinierte Empfänger)
- [x] Responsive Web-UI (Bulma CSS)
- [x] Docker-Setup (Dockerfile, docker-compose.yml, Gunicorn)
- [x] Anleitung erstellt (HTML-Slideshow)

### Offen

- [ ] Deployment auf Windows-Testrechner
- [ ] Praxistest aller 5 Dokumenttypen auf dem Zielsystem
